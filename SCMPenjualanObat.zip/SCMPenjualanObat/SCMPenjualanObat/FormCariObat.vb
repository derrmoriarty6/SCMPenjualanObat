Imports MySql.Data.MySqlClient
Public Class FormCariObat

    Private Sub caridataobat()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblobat WHERE kd_obat like '%" & Trim(txtCariData.Text) & "%' or nm_obat like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    'Mengambil data dari listview
    Private Sub AmbilDataDariListview()
        With ListView1.SelectedItems
            Try
                FormTransaksiPenjualan.txtKdObat.Text = .Item(0).SubItems(0).Text
                FormTransaksiPenjualan.txtNamaObat.Text = .Item(0).SubItems(1).Text
                FormTransaksiPenjualan.txtSatuan.Text = .Item(0).SubItems(4).Text
                FormTransaksiPenjualan.txtHargaSatuan.Text = .Item(0).SubItems(5).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub Posisilist()
        With ListView1.Columns
            .Add("Kode Obat", 80)
            .Add("Nama Obat", 150)
            .Add("Kategori", 80)
            .Add("Supplier", 80)
            .Add("Satuan", 80)
            .Add("Harga", 100)
            .Add("Stok", 60)
        End With
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblobat ORDER BY kd_obat"
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub FormCariObat_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        KoneksiKeDatabase()
        Posisilist()
        Isilist()
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridataobat()
    End Sub

    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridataobat()
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListview()
        Me.Close()
    End Sub

End Class
