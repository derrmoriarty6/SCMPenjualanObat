Imports MySql.Data.MySqlClient
Public Class FormTransaksiPenjualan

    Dim hargasatuan, totalharga As Double
    Dim jumlahbeli As Integer
    Dim idpenjualan As String

    Private Sub AmbilDataDariListview()
        With ListView1.SelectedItems
            Try
                idpenjualan = .Item(0).SubItems(0).Text
                dtpTglJual.Text = .Item(0).SubItems(1).Text
                txtKdObat.Text = .Item(0).SubItems(2).Text
                txtNamaObat.Text = .Item(0).SubItems(3).Text
                txtSatuan.Text = .Item(0).SubItems(4).Text
                txtJumlah.Text = .Item(0).SubItems(5).Text
                txtHargaSatuan.Text = .Item(0).SubItems(6).Text
                txtTotalHarga.Text = .Item(0).SubItems(7).Text
                txtNamaPembeli.Text = .Item(0).SubItems(8).Text
                txtKeterangan.Text = .Item(0).SubItems(9).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub posisilist()
        ListView1.Columns.Clear()
        ListView1.View = View.Details
        ListView1.FullRowSelect = True
        ListView1.GridLines = True

        With ListView1.Columns
            .Add("ID Transaksi", 80)
            .Add("Tanggal Jual", 100)
            .Add("Kode Obat", 80)
            .Add("Nama Obat", 150)
            .Add("Satuan", 80)
            .Add("Jumlah Beli", 80)
            .Add("Harga Satuan", 100)
            .Add("Total Harga", 100)
            .Add("Nama Pembeli", 120)
            .Add("Keterangan", 120)
        End With
    End Sub

    Private Sub isilist()
        Dim a As Integer
        Try
            query = "Select * From querypenjualan Order by id_penjualan ASC"
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(9))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(10))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(11))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(12))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(13))
                End With
            Next
        Catch ex As Exception
            MsgBox("Gagal menampilkan data: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub prosestotal()
        Try
            jumlahbeli = Val(txtJumlah.Text)
            hargasatuan = Val(txtHargaSatuan.Text)

            totalharga = jumlahbeli * hargasatuan

            txtTotalHarga.Text = totalharga
        Catch ex As Exception
        End Try
    End Sub

    Private Sub BtnCariObat_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCariObat.Click
        FormCariObat.ShowDialog()
    End Sub

    Private Sub BtnProses_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnProses.Click
        If txtJumlah.Text = "" Or txtHargaSatuan.Text = "" Then
            MsgBox("Masukkan jumlah beli dan pilih obat terlebih dahulu!", MsgBoxStyle.Exclamation, "Peringatan")
        Else
            prosestotal()
        End If
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If txtKdObat.Text = "" Or txtJumlah.Text = "" Or txtTotalHarga.Text = "" Or txtNamaPembeli.Text = "" Then
                MsgBox("Silahkan lengkapi data terlebih dahulu!", MsgBoxStyle.Critical, "Pesan Data Kosong")
            Else
                Call KoneksiKeDatabase()
                query = "insert into tblpenjualan(tgl_jual, kd_obat, jumlah, harga_satuan, total_harga, nama_pembeli, keterangan) values ('" & Format(dtpTglJual.Value, "yyyy/MM/dd") & "','" & txtKdObat.Text & "','" & txtJumlah.Text & "','" & txtHargaSatuan.Text & "','" & txtTotalHarga.Text & "','" & txtNamaPembeli.Text & "','" & txtKeterangan.Text & "')"
                daData = New MySqlDataAdapter(query, conn)
                dsData = New DataSet
                daData.Fill(dsData)
                MsgBox("Data Transaksi berhasil disimpan!", MsgBoxStyle.Information, "SAVE")
                isilist()
                bersihkandata()
            End If
        Catch ex As Exception
            MsgBox("Gagal menyimpan: " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub FormTransaksiPenjualan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        koneksiKeDataBase()
        posisilist()
        isilist()
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListview()
    End Sub

    Private Sub bersihkandata()
        dtpTglJual.Value = Now
        txtKdObat.Text = ""
        txtNamaObat.Text = ""
        txtSatuan.Text = ""
        txtJumlah.Text = ""
        txtHargaSatuan.Text = ""
        txtTotalHarga.Text = ""
        txtNamaPembeli.Text = ""
        txtKeterangan.Text = ""
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        bersihkandata()
        isilist()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            If idpenjualan = "" Or txtKdObat.Text = "" Or txtJumlah.Text = "" Or txtTotalHarga.Text = "" Then
                MsgBox("Pilih data yang akan diedit dari tabel", MsgBoxStyle.Critical, "Pesan Kosong")
            Else
                query = "Update tblpenjualan set tgl_jual='" & Format(dtpTglJual.Value, "yyyy/MM/dd") & "',kd_obat='" & txtKdObat.Text & "',jumlah='" & txtJumlah.Text & "',harga_satuan='" & txtHargaSatuan.Text & "',total_harga='" & txtTotalHarga.Text & "',nama_pembeli='" & txtNamaPembeli.Text & "',keterangan='" & txtKeterangan.Text & "' where id_penjualan='" & idpenjualan & "'"
                daData = New MySqlDataAdapter(query, conn)
                dsData = New DataSet
                daData.Fill(dsData)
                MsgBox("Data berhasil di edit!", MsgBoxStyle.Information, "Edit")
                isilist()
                bersihkandata()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            Dim A As String
            A = MsgBox("Benar data transaksi akan di delete...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case A
                Case vbCancel
                    Exit Sub
                Case vbOK
                    If idpenjualan = "" Then
                        MsgBox("Pilih transaksi yang akan dihapus", MsgBoxStyle.Exclamation, "Peringatan")
                    Else
                        query = "DELETE from tblpenjualan WHERE id_penjualan='" & idpenjualan & "'"
                        daData = New MySqlDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        isilist()
                        bersihkandata()
                        MsgBox("Data Transaksi Berhasil Di Delete", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Hapus Data")
                    End If
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub btnCetak_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCetak.Click
        If txtKdObat.Text = "" Or txtTotalHarga.Text = "" Then
            MsgBox("Pilih data transaksi dari tabel terlebih dahulu!", MsgBoxStyle.Exclamation, "Peringatan")
        Else
            PrintPreviewDialog1.Document = PrintDocument1
            PrintPreviewDialog1.ShowDialog()
        End If
    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim fontJudul As New Font("Courier New", 14, FontStyle.Bold)
        Dim fontAlamat As New Font("Courier New", 9, FontStyle.Regular)
        Dim fontIsi As New Font("Courier New", 10, FontStyle.Regular)
        Dim fontIsiBold As New Font("Courier New", 10, FontStyle.Bold)
        Dim fontFooter As New Font("Courier New", 9, FontStyle.Italic)

        Dim x As Integer = 50
        Dim y As Integer = 30
        Dim garis As String = "=========================================="
        Dim garisTipis As String = "------------------------------------------"

        'Header Struk
        e.Graphics.DrawString(garis, fontIsi, Brushes.Black, x, y)
        y += 20
        e.Graphics.DrawString("          APOTEK MAJU", fontJudul, Brushes.Black, x, y)
        y += 22
        e.Graphics.DrawString("   Jl. Kesehatan No. 123, Kota", fontAlamat, Brushes.Black, x, y)
        y += 16
        e.Graphics.DrawString("      Telp: (021) 123-4567", fontAlamat, Brushes.Black, x, y)
        y += 18
        e.Graphics.DrawString(garis, fontIsi, Brushes.Black, x, y)
        y += 22

        'Detail Transaksi
        e.Graphics.DrawString("No. Transaksi : " & idpenjualan, fontIsi, Brushes.Black, x, y)
        y += 18
        e.Graphics.DrawString("Tanggal       : " & Format(dtpTglJual.Value, "dd/MM/yyyy"), fontIsi, Brushes.Black, x, y)
        y += 18
        e.Graphics.DrawString("Pembeli       : " & txtNamaPembeli.Text, fontIsi, Brushes.Black, x, y)
        y += 20
        e.Graphics.DrawString(garisTipis, fontIsi, Brushes.Black, x, y)
        y += 20

        'Detail Obat
        e.Graphics.DrawString("Obat          : " & txtNamaObat.Text, fontIsi, Brushes.Black, x, y)
        y += 18
        e.Graphics.DrawString("Kode Obat     : " & txtKdObat.Text, fontIsi, Brushes.Black, x, y)
        y += 18
        e.Graphics.DrawString("Satuan        : " & txtSatuan.Text, fontIsi, Brushes.Black, x, y)
        y += 18
        e.Graphics.DrawString("Jumlah        : " & txtJumlah.Text, fontIsi, Brushes.Black, x, y)
        y += 18
        e.Graphics.DrawString("Harga Satuan  : Rp " & Format(Val(txtHargaSatuan.Text), "#,##0"), fontIsi, Brushes.Black, x, y)
        y += 20
        e.Graphics.DrawString(garisTipis, fontIsi, Brushes.Black, x, y)
        y += 20

        'Total
        e.Graphics.DrawString("TOTAL         : Rp " & Format(Val(txtTotalHarga.Text), "#,##0"), fontIsiBold, Brushes.Black, x, y)
        y += 18
        e.Graphics.DrawString("Status        : " & txtKeterangan.Text, fontIsi, Brushes.Black, x, y)
        y += 20
        e.Graphics.DrawString(garis, fontIsi, Brushes.Black, x, y)
        y += 20

        'Footer
        e.Graphics.DrawString("      Terima Kasih Telah Berbelanja", fontFooter, Brushes.Black, x, y)
        y += 16
        e.Graphics.DrawString("        di Apotek Maju!", fontFooter, Brushes.Black, x, y)
        y += 18
        e.Graphics.DrawString(garis, fontIsi, Brushes.Black, x, y)
    End Sub

End Class
