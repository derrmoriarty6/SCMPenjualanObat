Public Class FormLogin

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Dim user As String = txtUsername.Text.Trim()
        Dim pass As String = txtPassword.Text.Trim()

        If (user = "salsa" And pass = "salsa123") OrElse
           (user = "dinda" And pass = "dinda123") OrElse
           (user = "juan" And pass = "juan123") Then
            MsgBox("Login Berhasil! Selamat Datang " & user, MsgBoxStyle.Information, "Login Sukses")
            Me.Hide()
            F_MenuUtama.Show()
        Else
            MsgBox("Username atau Password salah!", MsgBoxStyle.Critical, "Login Gagal")
            txtPassword.Clear()
            txtUsername.Focus()
        End If
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub

End Class
