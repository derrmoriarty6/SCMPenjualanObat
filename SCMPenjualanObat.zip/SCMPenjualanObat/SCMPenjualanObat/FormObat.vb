Imports MySql.Data.MySqlClient
Public Class FormObat
    
    Private Sub posisilist()
        With ListView1.Columns
            .Add("Kode Obat", 80)
            .Add("Nama Obat", 150)
            .Add("Kategori", 80)
            .Add("Supplier", 80)
            .Add("Satuan", 80)
            .Add("Harga", 100)
            .Add("Stok", 60)
        End With
    End Sub

    Private Sub Isilist()
        Dim a As Integer
        Try
            query = "SELECT * FROM tblobat ORDER BY kd_obat"
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()

            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    Private Sub caridataobat()
        Dim a As Integer
        Try
            query = "select * From tblobat WHERE kd_obat like '%" & Trim(txtCariData.Text) & "%' or nm_obat like '%" & Trim(txtCariData.Text) & "%' "
            daData = New MySqlDataAdapter(query, conn)
            dsData = New DataSet
            daData.Fill(dsData)
            ListView1.Items.Clear()
            For a = 0 To dsData.Tables(0).Rows.Count - 1
                With ListView1
                    .Items.Add(dsData.Tables(0).Rows(a).Item(0))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(1))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(2))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(3))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(4))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(5))
                    .Items(a).SubItems.Add(dsData.Tables(0).Rows(a).Item(6))
                End With
            Next
        Catch ex As Exception
        End Try
    End Sub

    'Mengambil data dari ListView
    Private Sub AmbilDataDariListView()
        With ListView1.SelectedItems
            Try
                txtKdObat.Text = .Item(0).SubItems(0).Text
                txtNamaObat.Text = .Item(0).SubItems(1).Text
                txtKdKategori.Text = .Item(0).SubItems(2).Text
                txtKdSupplier.Text = .Item(0).SubItems(3).Text
                cboSatuan.Text = .Item(0).SubItems(4).Text
                txtHarga.Text = .Item(0).SubItems(5).Text
                txtStok.Text = .Item(0).SubItems(6).Text
            Catch ex As Exception
            End Try
        End With
    End Sub

    Private Sub FormObat_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Call koneksiKeDataBase()
            Call posisilist()
            Call Isilist()
            
            cboSatuan.Items.Add("Strip")
            cboSatuan.Items.Add("Botol")
            cboSatuan.Items.Add("Tablet")
            cboSatuan.Items.Add("Kapsul")
            cboSatuan.Items.Add("Sachet")
            cboSatuan.Items.Add("Tube")
            
        Catch ex As Exception
        End Try
    End Sub

    Private Sub btnRefresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefresh.Click
        Bersih()
        Isilist()
    End Sub

    Private Sub Bersih()
        txtKdObat.Text = ""
        txtNamaObat.Text = ""
        txtKdKategori.Text = ""
        txtKdSupplier.Text = ""
        cboSatuan.Text = ""
        txtHarga.Text = ""
        txtStok.Text = ""
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If txtKdObat.Text = "" Or txtNamaObat.Text = "" Or txtKdKategori.Text = "" Or txtKdSupplier.Text = "" Or cboSatuan.Text = "" Or txtHarga.Text = "" Or txtStok.Text = "" Then
                MsgBox("silahkan lengkapi data terlebih dahulu", MsgBoxStyle.Critical, "pesan data kosong")
                txtKdObat.Focus()
            Else
                query = "Insert Into tblobat Values('" & txtKdObat.Text & "','" & txtNamaObat.Text & "','" & txtKdKategori.Text & "','" & txtKdSupplier.Text & "','" & cboSatuan.Text & "','" & txtHarga.Text & "','" & txtStok.Text & "')"
                daData = New MySqlDataAdapter(query, conn)
                dsData = New DataSet
                daData.Fill(dsData)
                MsgBox("Data berhasil di simpan!", MsgBoxStyle.Information, "SAVE")
                txtKdObat.Focus()
                Isilist()
                Bersih()
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
            txtKdObat.Focus()
        End Try
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        Try
            If txtKdObat.Text = "" Or txtNamaObat.Text = "" Or txtKdKategori.Text = "" Or txtKdSupplier.Text = "" Or cboSatuan.Text = "" Or txtHarga.Text = "" Or txtStok.Text = "" Then
                MsgBox("silahkan Pilih Data Yang Akan Di Edit!", MsgBoxStyle.Critical, "pesan data kosong")
                txtKdObat.Focus()
            Else
                query = "UPDATE tblobat SET nm_obat='" & txtNamaObat.Text & "',kd_kategori='" & txtKdKategori.Text & "',kd_supplier='" & txtKdSupplier.Text & "',satuan='" & cboSatuan.Text & "',harga='" & txtHarga.Text & "',stok='" & txtStok.Text & "' WHERE kd_obat='" & txtKdObat.Text & "'"
                daData = New MySqlDataAdapter(query, conn)
                dsData = New DataSet
                daData.Fill(dsData)
                Isilist()
                Bersih()
                txtKdObat.Focus()
                MsgBox("Data Berhasil Di Edit!", MsgBoxStyle.Information, "Edit Data")
            End If
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub

    Private Sub ListView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView1.SelectedIndexChanged
        AmbilDataDariListView()
    End Sub
    
    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            Dim a As MsgBoxResult
            a = MsgBox("Bener data akan Di Delete ...?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Hapus Data")
            Select Case a
                Case vbCancel
                    txtKdObat.Focus()
                    Exit Sub
                Case vbOK
                    If txtKdObat.Text = "" Then
                        MsgBox("Input Kode Obat yang akan di hapus", MsgBoxStyle.Critical, "Data Kosong")
                    Else
                        query = "Delete From tblobat Where kd_obat='" & txtKdObat.Text & "'"
                        daData = New MySqlDataAdapter(query, conn)
                        dsData = New DataSet
                        daData.Fill(dsData)
                        Isilist()
                        Bersih()
                        MsgBox("data berhasil di delete!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "Hapus Data")
                    End If
            End Select
        Catch ex As Exception
            MsgBox("Error : " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "Hapus data")
        End Try
    End Sub

    Private Sub btnCariKategori_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariKategori.Click
        FormCariKategori.ShowDialog()
    End Sub

    Private Sub btnCariSupplier_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariSupplier.Click
        FormCariSupplier.ShowDialog()
    End Sub

    Private Sub txtCariData_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCariData.TextChanged
        caridataobat()
    End Sub
    
    Private Sub btnCariData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCariData.Click
        caridataobat()
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class
